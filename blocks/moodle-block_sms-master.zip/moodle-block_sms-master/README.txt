SMS Notification Block
Author: 3iLogicPlugin Instalation
1) Copy plugin folder in moodle blocks folder
2) Login with Administrator on Moodle site
3) Install the plugin by clicking on 'update database' now button
4) Put SMS API ID, username and password in setting page
______________________________
Clickatell
For Clickatell API, See http://www.clickatell.com
_______________________________
1) Create a developer account on Clickatell.com
2) Login with developer account
3) Click on Manage my Products tab
4) Copy API ID and paste it on Moodle setting page with username and password
____________________________________________

